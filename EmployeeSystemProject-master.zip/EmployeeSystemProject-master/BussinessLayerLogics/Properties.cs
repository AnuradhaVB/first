﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLayerLogics
{
    public class Properties
    {

        public string Firstname { get; set; }
        public string Lastname { get; set; }

        public DateTime DOB { get; set; }
        public int Mobilenumber { get; set; }
        public string Designation { get; set; }

        public string EmployeeId { get; set; }
      

    }
}
