﻿namespace IProperities
{
    public class Class1
    {

    }
}